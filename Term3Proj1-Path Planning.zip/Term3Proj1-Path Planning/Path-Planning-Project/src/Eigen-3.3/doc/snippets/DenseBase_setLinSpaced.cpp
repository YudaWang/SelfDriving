VectorXf v;
v.setLinSpaced(5,0.5f,1.5f);
cout << v << endl;
